FishFinder North America
========================
This version adds a North American Species Explorer.

Reference scope:
- 5,089 fish species in the 2023 AFS/ASIH North America checklist
- Canada, United States, Mexico
- Freshwater + marine + migratory fishes
- 333 families

The app contains a practical in-app angler catalog and links to the full FishBase Americas
search for complete species-level lookup. The 5,089-species commercial AFS/ASIH checklist
itself is not reproduced in full inside this app.

Files:
- FishFinder/index.html
